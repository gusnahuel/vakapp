<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreRazaRequest;
use App\Http\Requests\UpdateRazaRequest;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\Raza;
use Inertia\Inertia;
use Exception;

class RazaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $razas = Raza::filter(Request::only('search', 'trashed'));

        if (request()->query('sort')) {
            $attribute = request()->query('sort');
            $sort_order = 'ASC';
            if (strncmp($attribute, '-', 1) === 0) {
                $sort_order = 'DESC';
                $attribute = substr($attribute, 1);
            }
            $razas->orderBy($attribute, $sort_order);
        } else {
            $razas->orderBy('id','desc');
        }
 
        $razas = $razas->paginate(10);

        return Inertia::render('Raza/Index', [
            'filters' => Request::all('search', 'trashed'),
            'razas' => $razas 
        ]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        return Inertia::render('Raza/Create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRazaRequest $request)
    {
        try{
            $attributes = $request->all();

        
            Raza::create($attributes);
    
            return Redirect::route('raza.index')->with('success', 'Se a creado un nueva Raza.');
        }catch (Exception $e) {
            return redirect()->back()->withErrors([
                'error' => 'ups, there was an error'
            ]);
        }

  
    }

    /**
     * Display the specified resource.
     */
    public function show(Raza $client)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $data = Raza::findOrFail($id);
        
        return Inertia::render('Raza/Edit', ['data' => $data]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRazaRequest $request,$id)
    {
        

        try{
            $data = Raza::findOrFail($id);
            $attributes = $request->all();
    
            $data->update($attributes);
    
            return Redirect::route('raza.index')->with('success',  "Se ha actualizado la raza ");
        }catch (Exception $e) {
            return redirect()->back()->withErrors([
                'error' => 'ups, there was an error'
            ]);
        }

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {


        try{
            $raza = Raza::findOrFail($id);
            $raza->delete();
    
            return Redirect::route('raza.index')->with('success', 'Se ha eliminado una raza.');
        }catch (Exception $e) {
            return redirect()->back()->withErrors([
                'error' => 'ups, there was an error'
            ]);
        }
       
    }

    /**
     * buscar ne lista
     */
    public function search(){

        $input=Request::all();
        $keyword=$input['keyword'] ;

        if (is_numeric($keyword)){
            $query=Raza:: where('id', 'ILIKE', '%' . $keyword . '%');
        }else{
            $query=Raza::whereRaw("LOWER(CONVERT(nombre USING utf8)) LIKE LOWER(?)", ['%'.$keyword.'%']);
         
        }
        $data = $query->paginate(20);
        return response()->json($data); 
    }
}
