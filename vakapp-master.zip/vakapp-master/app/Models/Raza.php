<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Raza extends Model
{
    use HasFactory;

    protected $table= 'razas';


    protected $fillable=[
        'id',
        'nombre',

    ];


    public static $rulesCreated = [
        'nombre' => 'required',

    ]; 

    public static $rulesUpdated = [
        'nombre' => 'required',
    ]; 



    public function scopeFilter($query, array $filters)
    {

        $query->when($filters['search'] ?? null, function ($query, $search) {
            $query->whereRaw("LOWER(CONVERT(nombre USING utf8)) LIKE LOWER(?)", ['%'.$search.'%']);
        });
    }

}
