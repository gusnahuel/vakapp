<script setup>

import { ref ,watch} from 'vue';
import {Link, useForm , router} from '@inertiajs/vue3';
import AppLayout from '@/Layouts/AppLayout.vue';

// import Breadcrumb from '@/Components/Breadcrumbs.vue';
import Sort from '@/Components/Sort.vue';
import SearchFilter from "@/Components/SearchFilter.vue";
import Icon from "@/Components/Icon.vue";
import FlashMessages from '@/Components/FlashMessages.vue';
import Pagination from "@/Components/Pagination.vue";


import throttle from "lodash/throttle";
import pickBy from "lodash/pickBy";
import Swal from 'sweetalert2';

const props = defineProps({
    razas: Object,
    filters: Object
});


const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

/////////////////////////search

const form = useForm({
  search: props.filters.search,
  trashed: props.filters.trashed,

})

watch(
  form,
  throttle(() => {
    router.get('/raza', pickBy(form), { remember: 'forget', preserveState: true })
  }, 150),
  { deep: true },
)

const reset = () => {
  form.reset()
}

const viewAll= () => {
  router.get('/raza');
}

/////////////////////// fin search



//////////// borrar
function deleteItem(data) {

Swal.fire({
  title: 'Cuidado',
  text: "Quiere eliminar este registro?",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonText: 'Sí, borralo',
  cancelButtonText: 'Cancelar',
  confirmButtonColor: '#d33',
}).then((result) => {
  if (result.isConfirmed) {

    data._method = "DELETE";
    router.delete(route("raza.destroy", data.id), {

      preserveScroll: true,
      onSuccess: () => {

        Toast.fire({
          icon: 'success',
          title: 'Se ha borrado correctamente'
        });
      },
    });
  }
});
}




</script>
<template>
     <AppLayout title="Razas">
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Lista de Razas
            </h2>
        </template>
        <template #description><Breadcrumb :breadcrumbs="migasDePan"/>  </template>
        <template #links>
            <Link
                class="bg-indigo-500 text-white active:bg-indigo-600 text-xs font-bold uppercase px-3 py-2 rounded outline-none focus:outline-none mr-1 mb-1"
                :href="route('raza.create')" style="transition: all 0.15s ease">
            <span>Crear </span>
            <span class="hidden md:inline">Raza</span>
            </Link>
        </template>
        <div class=" max-w-12xl mx-auto p-4 ">
         
            <!-- component -->
           
         

                <div class="mt-6 md:flex md:items-center md:justify-between">
                    <div class="inline-flex overflow-hidden bg-white border divide-x rounded-lg dark:bg-gray-900 rtl:flex-row-reverse dark:border-gray-700 dark:divide-gray-700">
                        <button @click="viewAll"
                            class="px-5 py-2 text-xs font-medium text-gray-600 transition-colors duration-200 bg-gray-100 sm:text-sm dark:bg-gray-800 dark:text-gray-300">
                            Ver todo
                        </button>

                        <button
                            class="px-5 py-2 text-xs font-medium text-gray-600 transition-colors duration-200 sm:text-sm dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
                            <Sort label="ID" attribute="id" />
                        </button>

                        <!-- <button class="px-5 py-2 text-xs font-medium text-gray-600 transition-colors duration-200 sm:text-sm dark:hover:bg-gray-800 dark:text-gray-300 hover:bg-gray-100">
                            Unmonitored
                        </button> -->
                    </div>

                    <div class="relative flex items-center mt-4 md:mt-0">
                        <search-filter v-model="form.search" @reset="reset">
                        </search-filter>

                    </div>
                </div>
                <FlashMessages />
                <div class="flex flex-col mt-6">
                    <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden border border-gray-200 dark:border-gray-700 md:rounded-lg">
                                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                    <thead class="bg-gray-50 dark:bg-gray-800">
                                        <tr>
                                            <th scope="col" class="py-3.5 px-4 text-sm font-normal text-left rtl:text-right text-gray-500 dark:text-gray-400">
                                                <button class="flex items-center gap-x-3 focus:outline-none">
                                                    <span>ID</span>

                                                
                                                </button>
                                            </th>

                                            <th scope="col" class="px-12 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500 dark:text-gray-400">
                                                Nombre
                                            </th>

                                            <!-- <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500 dark:text-gray-400">
                                                About
                                            </th>

                                            <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500 dark:text-gray-400">Users</th>

                                            <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-500 dark:text-gray-400">License use</th> -->

                                            <th scope="col" class="relative py-3.5 px-4">
                                                <span class="sr-only">Edit</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200 dark:divide-gray-700 dark:bg-gray-900">
                                        <tr v-for="row in razas.data"  :key="row.id">
                                            <td class="px-4 py-4 text-sm font-medium whitespace-nowrap">
                                             {{ row.id }}
                                            </td>
                                            <td class="px-12 py-4 text-sm font-medium whitespace-nowrap">
                                                <div class="inline px-3 py-1 text-sm font-normal rounded-full text-emerald-500 gap-x-2 bg-emerald-100/60 dark:bg-gray-800">
                                                    {{ row?.nombre }}
                                                </div>
                                            </td>
                                            <!-- <td class="px-4 py-4 text-sm whitespace-nowrap">
                                                <div>
                                                    <h4 class="text-gray-700 dark:text-gray-200">Content curating app</h4>
                                                    <p class="text-gray-500 dark:text-gray-400">Brings all your news into one place</p>
                                                </div>
                                            </td>
                                            <td class="px-4 py-4 text-sm whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <img class="object-cover w-6 h-6 -mx-1 border-2 border-white rounded-full dark:border-gray-700 shrink-0" src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80" alt="">
                                                    <img class="object-cover w-6 h-6 -mx-1 border-2 border-white rounded-full dark:border-gray-700 shrink-0" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80" alt="">
                                                    <img class="object-cover w-6 h-6 -mx-1 border-2 border-white rounded-full dark:border-gray-700 shrink-0" src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1256&q=80" alt="">
                                                    <img class="object-cover w-6 h-6 -mx-1 border-2 border-white rounded-full dark:border-gray-700 shrink-0" src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80" alt="">
                                                    <p class="flex items-center justify-center w-6 h-6 -mx-1 text-xs text-blue-600 bg-blue-100 border-2 border-white rounded-full">+4</p>
                                                </div>
                                            </td>

                                            <td class="px-4 py-4 text-sm whitespace-nowrap">
                                                <div class="w-48 h-1.5 bg-blue-200 overflow-hidden rounded-full">
                                                    <div class="bg-blue-500 w-2/3 h-1.5"></div>
                                                </div>
                                            </td> -->

                                            <td class="px-4 py-4 text-sm whitespace-nowrap">
                                                <div class="flex justify-end gap-4">
                                                    <Link :href="route('raza.edit', row.id)" style="transition: all 0.15s ease" title="Editar">
                                                        <Icon :icon="'heroicons-outline:pencil'"
                                                        class="w-8 h-8 hover:text-blue-600 rounded-xl hover:bg-blue-200 p-1" />

                                                    </Link>
                                                    <button @click="deleteItem(row)" title="Borrar">
                                                    <Icon :icon="'heroicons-outline:trash'"
                                                        class="w-8 h-8 hover:text-red-600 rounded-xl hover:bg-red-200 p-1" />

                                                    </button>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>

                                <div class="px-5 py-5 bg-white border-t  items-center xs:justify-between  dark:text-white dark:divide-gray-700 dark:bg-gray-900">
                                <pagination :data="razas" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


           
        </div>

     </AppLayout>


</template>