<script setup>
import AppLayout from "@/Layouts/AppLayout.vue";

import Breadcrumb from '@/Components/Breadcrumbs.vue';
import ActionMessage from '@/Components/ActionMessage.vue';
import FormSection from '@/Components/FormSection.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import { Link, useForm,usePage } from '@inertiajs/vue3';
import { computed , onMounted} from 'vue';


const migasDePan = [
  { label: 'Raza', url: 'raza.index' },
  { label: 'Crear Raza', url: null },
];


const page = usePage()
const user = computed(() => page.props.auth.user);

const props = defineProps({
  data: Object,
  errors: Object,
  clientTypes: Object,
})



const form = useForm({
  _method: "PUT",
  nombre: props.data.nombre,

});


const submit = () => {

  form.post(route("raza.update", props.data.id), {
    errorBag: "updateRaza",
    preserveScroll: true,
  });

};

onMounted(() => {
  document.getElementById('nombre').focus();
});
</script>

<template>
  <AppLayout title="Editar raza">

    <div>
      <div class="max-w-12xl mx-auto ">
        <FormSection @submitted="submit">
          <template #messager>
            <Breadcrumb class="-mt-2" :breadcrumbs="migasDePan"/> 
            <FlashMessages />
          </template>
          <template #title> Editar Raza</template>

          <template #description>
            Formulario para editar raza. Complete los datos requeridos


    

        
          </template>

          <template #form>
            <!-- Profile Photo -->



            <!-- Email -->
            <div class="col-span-6 sm:col-span-3">
              <InputLabel for="nombre" value="Nombre" />
              <TextInput id="nombre" type="text" class="mt-1 block w-full" v-model="form.nombre" />
              <InputError :message="form.errors.nombre" class="mt-2" />
            </div>
            

          </template>

          <template #actions>
            <Link
              class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:text-gray-500 focus:outline-none focus:border-blue-300 focus:ring focus:ring-blue-200 active:text-gray-800 active:bg-gray-50 disabled:opacity-25 transition"
              :href="route('raza.index')" style="transition: all 0.15s ease">
            <span class="">Cancelar</span>
            </Link>
            <ActionMessage :on="form.recentlySuccessful" class="mr-3">
              Saved.
            </ActionMessage>

            <PrimaryButton :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
              Guardar
            </PrimaryButton>
          </template>
        </FormSection>
      </div>
    </div>
  </AppLayout>
</template>
