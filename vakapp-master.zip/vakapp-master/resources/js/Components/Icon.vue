<script setup>
import { Icon } from '@iconify/vue';

defineProps({
    icon: {
        type: String,
        default: 'heroicons-outline:home',
    },
    class: {
        type: String,
        default: '',
    },

});
</script>
<template>
    <span>
        <Icon :icon="icon" :class="class" />
    </span>
</template>




<style lang=""></style>