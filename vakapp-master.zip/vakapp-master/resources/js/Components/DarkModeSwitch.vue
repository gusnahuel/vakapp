<script setup>
import {ref,onMounted } from 'vue';

const darkMode= ref(false);

function toggleDarkMode() {
    darkMode.value = !darkMode.value;
    document.documentElement.classList.toggle('dark', darkMode.value);


    if (darkMode.value) {
        localStorage.theme = 'dark';
    } else {
        localStorage.theme = 'light';
    }

}

onMounted(() => {
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        darkMode.value = true;
        document.documentElement.classList.add('dark');
    } else {
        darkMode.value = false;
        document.documentElement.classList.remove('dark');
    }
});
</script>

<template>
    <button @click="toggleDarkMode">
        {{ darkMode ? 'Modo Claro' : 'Modo Oscuro' }}
    </button>
</template>
  
