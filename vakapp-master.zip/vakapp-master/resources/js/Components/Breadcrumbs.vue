<script setup>
import Icon from "@/Components/Icon.vue";
import { Link} from '@inertiajs/vue3';



const props = defineProps({
  breadcrumbs:Object,
  labelLast: {
    type: String,
    default: "",
  },

})


</script>
<style >
.breadcrumbs {
  display: flex;
  font-size: 0.875rem;
  gap: 0.5rem;
  align-items: center;
}

.breadcrumbs li {
  position: relative;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-transform: capitalize;
  font-weight: normal;
}

.breadcrumbs li .breadcrumbs-icon {
  font-size: 1.25rem;
  color: var(--secondary-500); /* Reemplaza "--secondary-500" con el color deseado */
}

</style>

<template>
  <div class="flex items-center space-x-3 rtl:space-x-reverse">
    <!-- {{ breadcrumbs }} -->
    <ul class="breadcrumbs">
      <li class="text-primary-500">
        <Link :href="route('dashboard.index')" class="text-lg">
        <Icon icon="heroicons-outline:home" />
        </Link>
        <span class="breadcrumbs-icon rtl:transform rtl:rotate-180">
          <Icon icon="heroicons:chevron-right" />
        </span>
      </li>
      <li  v-for="(breadcrumb, index) in breadcrumbs" :key="index">


        <template v-if="breadcrumb.url">
         
          <Link :href="route(breadcrumb.url)" class="text-primary-500">{{ breadcrumb.label }}</Link>
          <span class="breadcrumbs-icon rtl:transform rtl:rotate-180 text-primary-500" >
            <Icon icon="heroicons:chevron-right" />
          </span>
        </template>
        <span v-else>{{ breadcrumb.label }}</span>
       

      </li>
     
    </ul>
  </div>
</template>
